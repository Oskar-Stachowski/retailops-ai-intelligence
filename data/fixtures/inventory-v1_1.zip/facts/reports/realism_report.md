# Observed-sales realism

Policy: inventory-observed-sales-realism-1.0.0. Status: diagnostic.

| Metric | Sample | Value | Threshold | Status |
|---|---:|---|---|---|
| top_20_percent_catalog_revenue_share | 3 | 0.6038304950101783 | {'min': 0.45, 'max': 0.8, 'minimum_sample': 50} | not_evaluable |
| average_distinct_order_items | 72 | 1.3194444444444444 | {'min': 1.2, 'max': 3.5, 'minimum_sample': 30} | passed |
| open_panel_zero_rate | 84 | 0.4523809523809524 | {'min': 0, 'max': 1} | passed |
| causal_promotion_uplift | 95 | None | None | not_ready |
| open_panel_zero_rate:declining_product/Home Improvement/online | 10 | 0.1 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Home Improvement/store | 18 | 0.1111111111111111 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Grocery/online | 10 | 1.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Grocery/store | 18 | 0.8333333333333334 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:seasonal/Electronics/online | 10 | 0.4 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:seasonal/Electronics/store | 18 | 0.3333333333333333 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:declining_product/Home Improvement/online | 13 | 0.23076923076923078 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:declining_product/Home Improvement/store | 38 | 0.05263157894736842 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:long_tail/Grocery/store | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:seasonal/Electronics/online | 26 | 0.19230769230769232 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:seasonal/Electronics/store | 70 | 0.05714285714285714 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |

Bounded synthetic data is not a production distribution or model benchmark.

Inventory diagnostics: {"denominator": "All physical inventory positions/days, including inactive assortment; not an AI08 sample.", "label_qualification": "not_evaluated", "latent_units": 245, "lost_unit_share": 0.3877551020408163, "lost_units": 95, "physical_scope_days": 60, "physical_zero_balance_share": 0.21666666666666667, "stockout_episodes": 6}
