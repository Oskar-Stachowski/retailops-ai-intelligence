# Observed-sales realism

Policy: inventory-observed-sales-realism-1.0.0. Status: diagnostic.

| Metric | Sample | Value | Threshold | Status |
|---|---:|---|---|---|
| top_20_percent_catalog_revenue_share | 8 | 0.541998069418433 | {'min': 0.45, 'max': 0.8, 'minimum_sample': 50} | not_evaluable |
| average_distinct_order_items | 896 | 1.5636160714285714 | {'min': 1.2, 'max': 3.5, 'minimum_sample': 30} | passed |
| open_panel_zero_rate | 618 | 0.3478964401294498 | {'min': 0, 'max': 1} | passed |
| causal_promotion_uplift | 1401 | None | None | not_ready |
| open_panel_zero_rate:core_product/Electronics/online | 30 | 0.43333333333333335 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Electronics/store | 52 | 0.36538461538461536 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Home Improvement/online | 30 | 0.4666666666666667 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Home Improvement/store | 52 | 0.34615384615384615 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Beauty/online | 30 | 0.03333333333333333 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Beauty/store | 52 | 0.11538461538461539 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Sports/online | 23 | 0.13043478260869565 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Sports/store | 40 | 0.025 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Pet Care/online | 30 | 0.6 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Pet Care/store | 52 | 0.75 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Toys/online | 30 | 0.36666666666666664 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Toys/store | 52 | 0.6538461538461539 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:new_product/Fashion/online | 23 | 0.2608695652173913 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:new_product/Fashion/store | 40 | 0.175 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:seasonal/Grocery/online | 30 | 0.36666666666666664 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:seasonal/Grocery/store | 52 | 0.2692307692307692 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Electronics/online | 276 | 0.09782608695652174 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Electronics/store | 426 | 0.07276995305164319 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/online | 288 | 0.1875 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/store | 522 | 0.10153256704980843 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Beauty/online | 45 | 0.08888888888888889 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Beauty/store | 64 | 0.078125 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Sports/online | 52 | 0.15384615384615385 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Sports/store | 80 | 0.0625 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:long_tail/Pet Care/online | 12 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Pet Care/store | 13 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Toys/online | 19 | 0.21052631578947367 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Toys/store | 18 | 0.16666666666666666 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:new_product/Fashion/online | 98 | 0.4489795918367347 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:new_product/Fashion/store | 130 | 0.23846153846153847 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:seasonal/Grocery/online | 141 | 0.014184397163120567 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:seasonal/Grocery/store | 222 | 0.0045045045045045045 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |

Bounded synthetic data is not a production distribution or model benchmark.

Inventory diagnostics: {"denominator": "All physical inventory positions/days, including inactive assortment; not an AI08 sample.", "label_qualification": "not_evaluated", "latent_units": 4864, "lost_unit_share": 0.5053453947368421, "lost_units": 2458, "physical_scope_days": 480, "physical_zero_balance_share": 0.2875, "stockout_episodes": 72}
