# Inventory source acceptance

Policy: anomaly-source-acceptance-1.0.0. Status: passed.

| Check | Status | Sample | Description |
|---|---|---:|---|
| dimension_schema_pk_sku | passed | 410 | All required records satisfy the policy. |
| selling_stock_channel_region | passed | 3 | All required records satisfy the policy. |
| assignment_routing_versions | passed | 6 | All required records satisfy the policy. |
| catalog_lifecycle_assortment | passed | 678 | All required records satisfy the policy. |
| calendar_exact_coverage | passed | 90 | All required records satisfy the policy. |
| category_season_coverage | passed | 240 | All required records satisfy the policy. |
| legacy_adapter_consistency | passed | 13 | All required records satisfy the policy. |
| sales_active_open_known_routing | passed | 1401 | All required records satisfy the policy. |
| pricing_schema_versions_scope | passed | 1896 | All required records satisfy the policy. |
| known_price_coverage_and_priority | passed | 678 | All required records satisfy the policy. |
| transaction_price_reconciliation | passed | 1401 | All required records satisfy the policy. |
| realized_price_aggregates | passed | 403 | All required records satisfy the policy. |
| legacy_pricing_adapter | passed | 50 | All required records satisfy the policy. |
| promotion_truth_direction | passed | 42 | All required records satisfy the policy. |
| demand_schema | passed | 1338 | All required records satisfy the policy. |
| daily_panel_coverage | passed | 678 | All required records satisfy the policy. |
| daily_transaction_aggregation | passed | 678 | All required records satisfy the policy. |
| basket_sku_totals | passed | 896 | All required records satisfy the policy. |
| daily_source_completeness | passed | 678 | All required records satisfy the policy. |
| returns_schema | passed | 1620 | All required records satisfy the policy. |
| return_window_policy | passed | 32 | All required records satisfy the policy. |
| transaction_chronology | passed | 1401 | All required records satisfy the policy. |
| return_reference_and_window | passed | 232 | All required records satisfy the policy. |
| return_quantity_and_refunds | passed | 232 | All required records satisfy the policy. |
| return_tail_completeness | passed | 678 | All required records satisfy the policy. |
| inventory_graph_and_projection | passed | 15280 | All required records reconcile. |
| commerce_inventory_parity | passed | 1401 | All required records reconcile. |
| inventory_configuration_binding | passed | 16 | All required records reconcile. |
| historical_fulfillment_adapter | passed | 6 | All required records reconcile. |
| private_supplier_realization | passed | 110 | All required records reconcile. |
| known_fact_reorder_policy | passed | 464 | All required records reconcile. |
| inventory_daily_demand_conservation | passed | 618 | All required records reconcile. |
| causal_observation_and_finance_history | passed | 678 | All required records reconcile. |
| private_simulation_parameters | passed | 11 | All required records reconcile. |
| forecast_feature_projection | passed | 678 | All required records reconcile. |
| inventory_known_completeness | passed | 480 | All required records reconcile. |
| anomaly_process_replay | passed | 3 | Checked by independent complete process replay before publication/read. |
| anomaly_effect_reconciliation | passed | 3 | Checked by independent complete process replay before publication/read. |

Source/inventory/model readiness remains false until the AI03 handoff and lifecycle qualification.
