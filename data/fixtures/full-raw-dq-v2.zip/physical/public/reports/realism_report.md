# Observed-sales realism

Policy: inventory-observed-sales-realism-1.0.0. Status: diagnostic.

| Metric | Sample | Value | Threshold | Status |
|---|---:|---|---|---|
| top_20_percent_catalog_revenue_share | 8 | 0.5414980285446385 | {'min': 0.45, 'max': 0.8, 'minimum_sample': 50} | not_evaluable |
| average_distinct_order_items | 900 | 1.5444444444444445 | {'min': 1.2, 'max': 3.5, 'minimum_sample': 30} | passed |
| open_panel_zero_rate | 618 | 0.3511326860841424 | {'min': 0, 'max': 1} | passed |
| causal_promotion_uplift | 1390 | None | None | not_ready |
| open_panel_zero_rate:core_product/Electronics/online | 30 | 0.4666666666666667 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Electronics/store | 52 | 0.38461538461538464 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Home Improvement/online | 30 | 0.36666666666666664 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:core_product/Home Improvement/store | 52 | 0.38461538461538464 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Beauty/online | 30 | 0.03333333333333333 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Beauty/store | 52 | 0.11538461538461539 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:declining_product/Sports/online | 23 | 0.13043478260869565 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Sports/store | 40 | 0.025 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Pet Care/online | 30 | 0.6 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Pet Care/store | 52 | 0.75 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Toys/online | 30 | 0.36666666666666664 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:long_tail/Toys/store | 52 | 0.6538461538461539 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:new_product/Fashion/online | 23 | 0.2608695652173913 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:new_product/Fashion/store | 40 | 0.2 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:seasonal/Grocery/online | 30 | 0.36666666666666664 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| open_panel_zero_rate:seasonal/Grocery/store | 52 | 0.2692307692307692 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Electronics/online | 270 | 0.07407407407407407 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Electronics/store | 422 | 0.07109004739336493 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/online | 311 | 0.2282958199356913 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/store | 505 | 0.10297029702970296 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Beauty/online | 45 | 0.06666666666666667 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Beauty/store | 64 | 0.078125 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Sports/online | 52 | 0.17307692307692307 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Sports/store | 80 | 0.0625 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:long_tail/Pet Care/online | 12 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Pet Care/store | 13 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Toys/online | 19 | 0.15789473684210525 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Toys/store | 18 | 0.16666666666666666 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:new_product/Fashion/online | 99 | 0.494949494949495 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:new_product/Fashion/store | 129 | 0.24031007751937986 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:seasonal/Grocery/online | 141 | 0.0070921985815602835 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:seasonal/Grocery/store | 222 | 0.0045045045045045045 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |

Bounded synthetic data is not a production distribution or model benchmark.

Inventory diagnostics: {"denominator": "All physical inventory positions/days, including inactive assortment; not an AI08 sample.", "label_qualification": "not_evaluated", "latent_units": 4796, "lost_unit_share": 0.4991659716430359, "lost_units": 2394, "physical_scope_days": 480, "physical_zero_balance_share": 0.28958333333333336, "stockout_episodes": 74}
